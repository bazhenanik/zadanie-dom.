function editUser(userId, userName) {
    document.getElementById('userId').value = userId;
    document.getElementById('name').value = userName;
    document.getElementById('submitButton').textContent = 'Update User';
}

function deleteUser(userId) {
    if (confirm('Are you sure you want to delete this user?')) {
        fetch(`/users/${userId}`, {
            method: 'DELETE'
        })
            .then(response => {
                if (response.ok) {
                    location.reload();
                } else {
                    alert('Error deleting user');
                }
            });
    }
}
